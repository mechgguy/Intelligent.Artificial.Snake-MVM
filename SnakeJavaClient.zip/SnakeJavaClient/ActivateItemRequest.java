record ActivateItemRequest(String item) {
}
