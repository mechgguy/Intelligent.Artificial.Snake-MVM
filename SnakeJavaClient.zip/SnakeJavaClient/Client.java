class Client {
    private final HttpSnakeFieldAPI api;

    public Client(String serverUrl, String teamName, String gameName, String password) {
        this.api = new HttpSnakeFieldAPI(serverUrl, teamName, gameName, password);
    }

    public void run() {
        try {
            Direction currentDirection = Direction.EAST;

            api.setDirection(currentDirection);

            while (true) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
                GameField field = api.getField();
                api.setDirection(currentDirection);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: java SnakeClient <team_name> <game_name> [password] [server_url]");
            System.out.println("Example: java SnakeClient team1 default secret http://localhost:3030");
            return;
        }

        String teamName = args[0];
        String gameName = args[1];
        String password = args.length > 2 ? args[2] : "test";
        String serverUrl = args.length > 3 ? args[3] : "http://localhost:3030";

        Client client = new Client(serverUrl, teamName, gameName, password);
        client.run();
    }
}
